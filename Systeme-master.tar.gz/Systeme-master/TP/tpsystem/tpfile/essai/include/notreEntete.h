// debut fichier notreEntete.h, a mettre dans le repertoire include
  int calculer(int a, int b);
// fin fichier notreEntete.h

