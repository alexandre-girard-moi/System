// debut fichier file2.cxx, a mettre dans le repertoire dirfile
  #include "notreEntete.h"
  int calculer(int a, int b) {
  return (a+b);
  }
// fin fichier file2.cxx
