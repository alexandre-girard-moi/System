/**
 *
 * @File : nsSysteme.cxx
 *
 *
 * @Synopsis : definition des wrappers non inline des fonctions syst
 *initialement vide
 *
**/


#include "nsSysteme.h"

